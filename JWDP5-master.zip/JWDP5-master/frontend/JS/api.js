export default {
    "api": "http://localhost:3000/api/teddies",
}